/* tslint:disable:no-unused-variable */

import { TestBed, async } from '@angular/core/testing';
import { CdsComponent } from './cds.component';

describe('Component: Cds', () => {
  it('should create an instance', () => {
    let component = new CdsComponent();
    expect(component).toBeTruthy();
  });
});
