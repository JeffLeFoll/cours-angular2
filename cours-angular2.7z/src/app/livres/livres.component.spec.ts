/* tslint:disable:no-unused-variable */

import { TestBed, async } from '@angular/core/testing';
import { LivresComponent } from './livres.component';

describe('Component: Livres', () => {
  it('should create an instance', () => {
    let component = new LivresComponent();
    expect(component).toBeTruthy();
  });
});
