/* tslint:disable:no-unused-variable */

import { TestBed, async } from '@angular/core/testing';
import { FilmsComponent } from './films.component';

describe('Component: Films', () => {
  it('should create an instance', () => {
    let component = new FilmsComponent();
    expect(component).toBeTruthy();
  });
});
