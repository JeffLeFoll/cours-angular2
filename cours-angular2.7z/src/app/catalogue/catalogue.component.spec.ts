/* tslint:disable:no-unused-variable */

import { TestBed, async } from '@angular/core/testing';
import { CatalogueComponent } from './catalogue.component';

describe('Component: Catalogue', () => {
  it('should create an instance', () => {
    let component = new CatalogueComponent();
    expect(component).toBeTruthy();
  });
});
